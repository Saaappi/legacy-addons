--[[
	Project			: Curator © 2019
	Author			: Oxlotus - Area 52-US
	Date Created	: 2019-06-28
	Purpose			: The powerhouse of all of the addon's localization.
]]--

local curatorClassic, curatorClassicNS = ...;

local L = setmetatable({}, { __index = function(t, k)
	local text = tostring(k);
	rawset(t, k, text);
	return text;
end });

curatorClassicNS.L = L;

local LOCALE = GetLocale();

if LOCALE == "enUS" or LOCALE == "enGB" then -- EU/US English
	-- GENERAL
	L["ADDON_NAME"] = "|cff00ccff" .. curatorClassic .. "|r: ";
	L["ADDON_NAME_HEADER"] = "|cff00ccff" .. "Curator: Classic" .. "|r";
	L["ADDED_ITEM"] = "Added ";
	L["REMOVED_ITEM"] = "Removed ";
	L["DELETED_ITEM"] = "Deleted ";
	-- COMMANDS
	L["CLEAN"] = "clean";
	-- ERRORS
	L["CANNOT_ADD_ITEM"] = " already exists in your account list!";
	L["LOW_FUNDS"] = "Funds not available for repair.";
	L["BAD_COMMAND"] = "Bad command! Please use clean";
	L["NO_ITEMS"] = "There are no items to sell or delete.";
	-- INFO
	L["CLEAN_OUTPUT"] = "Deleted item(s) using \"" .. L["CLEAN"] .. "\" command.";
	L["SOLD_ITEMS"] = "Sold item(s) for a net gain of ";
	L["REPAIRED_ITEMS"] = "Repaired all items for ";
	L["DELETED_ITEM_TEXT"] = " item(s) with no sell price.";
	L["NET_LOSS_TEXT"] = "You had a net loss of -";
	L["REPAIR_COST_TEXT"] = "Repairs: ";
	L["PROFIT_TEXT"] = "Profit: ";
	-- TOOLTIPS
	L["ITEM_ID"] = "Item ID";
	L["ITEM_STACK"] = "Stack";
	L["ITEM_COUNT"] = "Count";
	L["SELL_PRICE"] = "Sell Price";
	L["ACCOUNT_LIST"] = "This item is a member of your Account list.";
	L["CHAR_LIST"] = "This item is a member of your Character list.";
	-- BINDINGS
	L["BINDING_CURATORCLASSIC_ACCOUNT_LIST"] = "Account List";
	L["BINDING_CURATORCLASSIC_CHARACTER_LIST"] = "Character List";
	L["BINDING_CURATORCLASSIC_CHEAPEST_ITEM"] = "Identify Cheapest Item";
	L["BINDING_CURATORCLASSIC_DISPLAY_INFO"] = "Disable Item Info";
return end;

if LOCALE == "frFR" then -- French
	-- GENERAL
	L["ADDON_NAME"] = "|cff00ccff" .. curatorClassic .. "|r: ";
	L["ADDON_NAME_HEADER"] = "|cff00ccff" .. "Curator: Classic" .. "|r";
	L["ADDED_ITEM"] = "Ajoutée ";
	L["REMOVED_ITEM"] = "Enlevée ";
	L["DELETED_ITEM"] = "Supprimé ";
	-- COMMANDS
	L["CLEAN"] = "propre";
	-- ERRORS
	L["CANNOT_ADD_ITEM"] = " existe déjà dans votre liste de compte!";
	L["LOW_FUNDS"] = "Fonds non disponibles pour réparation.";
	L["BAD_COMMAND"] = "Mauvais commandement! Veuillez utiliser le nettoyer";
	L["NO_ITEMS"] = "Il n'y a aucun article à vendre ou supprimer.";
	-- INFO
	L["CLEAN_OUTPUT"] = "Élément(s) supprimé (s) à l'aide de la commande " .. L["nettoyer"] .. ".";
	L["SOLD_ITEMS"] = "Vendu tous les articles avec un gain net de ";
	L["REPAIRED_ITEMS"] = "Réparé tous les articles pour ";
	L["DELETED_ITEM_TEXT"] = " article(s) sans prix de vente.";
	L["NET_LOSS_TEXT"] = "Vous avez eu une perte nette de -";
	L["REPAIR_COST_TEXT"] = "Réparations: ";
	L["PROFIT_TEXT"] = "Profit: ";
	-- TOOLTIPS
	L["ITEM_ID"] = "L'ID de l'élément";
	L["ITEM_STACK"] = "Pile";
	L["ITEM_COUNT"] = "Compter";
	L["SELL_PRICE"] = "Prix De Vente";
	L["ACCOUNT_LIST"] = "Cet élément est un membre de votre liste de compte.";
	L["CHAR_LIST"] = "Cet objet est un membre de votre liste de personnages.";
	-- BINDINGS
	L["BINDING_CURATOR_ACCOUNT_LIST"] = "Compte Liste";
	L["BINDING_CURATOR_CHARACTER_LIST"] = "Personnage Liste";
	L["BINDING_CURATOR_CHEAPEST_ITEM"] = "Identifier l'article le moins cher";
	L["BINDING_CURATOR_DISPLAY_INFO"] = "Désactiver L'Élément Info";
return end;

if LOCALE == "deDE" then -- German
	-- GENERAL
	L["ADDON_NAME"] = "|cff00ccff" .. curatorClassic .. "|r: ";
	L["ADDON_NAME_HEADER"] = "|cff00ccff" .. "Curator: Classic" .. "|r";
	L["ADDED_ITEM"] = "Hinzugefügt ";
	L["REMOVED_ITEM"] = "Entfernt ";
	L["DELETED_ITEM"] = "Gelöscht ";
	-- COMMANDS
	L["CLEAN"] = "sauber";
	-- ERRORS
	L["CANNOT_ADD_ITEM"] = " ist bereits in Ihrer Kontoliste vorhanden!";
	L["LOW_FUNDS"] = "Mittel nicht verfügbar für die Reparatur.";
	L["BAD_COMMAND"] = "Schlechtes Kommando! Bitte verwenden sauber";
	L["NO_ITEMS"] = "Es gibt keine Artikel zu verkaufen oder zu löschen.";
	-- INFO
	L["CLEAN_OUTPUT"] = "Gelöschte Elemente mit dem Befehl " .. L["CLEAN"] .. ".";
	L["SOLD_ITEMS"] = "Verkauft alle Artikel mit einem Nettogewinn von ";
	L["REPAIRED_ITEMS"] = "Reparierte alle Einzelteile für ";
	L["DELETED_ITEM_TEXT"] = " Artikel ohne Verkaufspreis.";
	L["NET_LOSS_TEXT"] = "Sie hatten einen Nettoverlust von -";
	L["REPAIR_COST_TEXT"] = "Reparaturen: ";
	L["PROFIT_TEXT"] = "Profitieren: ";
	-- TOOLTIPS
	L["ITEM_ID"] = "Artikel-ID";
	L["ITEM_STACK"] = "Stack";
	L["ITEM_COUNT"] = "Zählen";
	L["SELL_PRICE"] = "Verkaufspreis";
	L["ACCOUNT_LIST"] = "Dieser Artikel ist ein Mitglied Ihrer Kontoliste.";
	L["CHAR_LIST"] = "Dieser Gegenstand ist ein Mitglied deiner Charakterliste.";
	-- BINDINGS
	L["BINDING_CURATOR_ACCOUNT_LIST"] = "Konto Liste";
	L["BINDING_CURATOR_CHARACTER_LIST"] = "Charakter Liste";
	L["BINDING_CURATOR_CHEAPEST_ITEM"] = "Identifizieren Sie den günstigsten Artikel";
	L["BINDING_CURATOR_DISPLAY_INFO"] = "Artikel-Info Deaktivieren";
return end;

if LOCALE == "ruRU" then -- Russian
	-- GENERAL
	L["ADDON_NAME"] = "|cff00ccff" .. curatorClassic .. "|r: ";
	L["ADDON_NAME_HEADER"] = "|cff00ccff" .. "Curator: Classic" .. "|r";
	L["ADDED_ITEM"] = "Добавить ";
	L["REMOVED_ITEM"] = "Удалены ";
	L["DELETED_ITEM"] = "Удалить ";
	-- COMMANDS
	L["CLEAN"] = "чистый";
	-- ERRORS
	L["CANNOT_ADD_ITEM"] = " уже существует на вашем аккаунте!";
	L["LOW_FUNDS"] = "Средства не доступны для ремонта.";
	L["BAD_COMMAND"] = "Плохая команда! Пожалуйста, используйте чистый";
	L["NO_ITEMS"] = "Там нет элементов, чтобы продать или удалить.";
	-- INFO
	L["CLEAN_OUTPUT"] = "Удаленные элементы с помощью команды " .. L["CLEAN"] .. ".";
	L["SOLD_ITEMS"] = "Проданы все предметы с чистой прибылью ";
	L["REPAIRED_ITEMS"] = "Отремонтировал все предметы для ";
	L["DELETED_ITEM_TEXT"] = " Предметы без цены продажи.";
	L["NET_LOSS_TEXT"] = "У вас был чистый убыток -";
	L["REPAIR_COST_TEXT"] = "Ремонт: ";
	L["PROFIT_TEXT"] = "Прибыль: ";
	-- TOOLTIPS
	L["ITEM_ID"] = "идентификаторы элементов";
	L["ITEM_STACK"] = "Стек";
	L["ITEM_COUNT"] = "Рассчитывать";
	L["SELL_PRICE"] = "Цена Продажи";
	L["ACCOUNT_LIST"] = "Этот предмет привязан к Списку Аккаунтов.";
	L["CHAR_LIST"] = "Этот предмет привязан к Списку Персонажей.";
	-- BINDINGS
	L["BINDING_CURATORCLASSIC_ACCOUNT_LIST"] = "Список аккаунтов";
	L["BINDING_CURATORCLASSIC_CHARACTER_LIST"] = "Список персонажей";
	L["BINDING_CURATORCLASSIC_CHEAPEST_ITEM"] = "Определить самый дешевый товар";
	L["BINDING_CURATOR_DISPLAY_INFO"] = "Отображение Информации Об Элементе";
return end;