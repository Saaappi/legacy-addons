--[[
	Project			: curatorClassic © 2019
	Author			: Oxlotus - Area 52-US
	Date Created	: 2019-06-12
	Purpose			: Main file of the addon.
]]--

-- Addon Variables
local curatorClassic, curatorClassicNS = ...;
local L = curatorClassicNS.L;

-- Module Variables
local frame = CreateFrame("Frame");
local mouseFrame = CreateFrame("Frame", "MouseFrame", UIParent);
local isAddonLoaded = IsAddOnLoaded("curatorClassic");
local cleanedItems = 0;
local deletedItemCount = 0;
local itemProfit = 0;
local addItem = true;
local doNotDisplayItemInfo = false;
local itemExists = false;
local itemHasNoSellPrice = false;
local tooltipLink;
local repairCost;
local sellIndices = {};
local characterName = GetUnitName("player", false) .. "-" .. GetRealmName();
local accountItemTotal = 0; -- How many of an item is available across the entire account?
local iter = 0; -- Where should I start iterating from?

-- Bindings
BINDING_HEADER_CURATORCLASSIC = L["ADDON_NAME_HEADER"];
BINDING_NAME_CURATORCLASSIC_ACCOUNT_LIST = L["BINDING_CURATORCLASSIC_ACCOUNT_LIST"];
BINDING_NAME_CURATORCLASSIC_CHARACTER_LIST = L["BINDING_CURATORCLASSIC_CHARACTER_LIST"];
BINDING_NAME_CURATORCLASSIC_DISABLE_DISPLAY_INFO = L["BINDING_CURATORCLASSIC_DISPLAY_INFO"];
BINDING_NAME_CURATORCLASSIC_CHEAPEST_ITEM = L["BINDING_CURATORCLASSIC_CHEAPEST_ITEM"];

-- Module Functions
local function Contains(itemID)
	for i = 1, #CuratorClassicSellListPerCharacter do
		if CuratorClassicSellListPerCharacter[i] == itemID then
			if select(11, GetItemInfo(itemID)) == 0 then
				itemHasNoSellPrice = true;
			else
				itemHasNoSellPrice = false;
			end
			
			return true;
		end
	end
	
	for i = 1, #CuratorClassicSellList do
		if CuratorClassicSellList[i] == itemID then
			if select(11, GetItemInfo(itemID)) == 0 then
				itemHasNoSellPrice = true;
			else
				itemHasNoSellPrice = false;
			end
			
			return true;
		end
	end
end

-- Module Init
local scanner = CreateFrame("GameTooltip", "curatorClassicScanner", UIParent, "GameTooltipTemplate"); scanner:SetOwner(UIParent,"ANCHOR_NONE");

local function DoesItemHaveSellPrice(itemLink)
	local sellPrice = select(11, GetItemInfo(itemLink));
	if sellPrice > 0 then return true else return false end;
end

local function CalculateProfit(item)
	if item then
		local itemCount = GetItemCount(item, false); local sellPrice = itemCount * select(11, GetItemInfo(item));
		
		return sellPrice;
	end
end

local function SellItems(tbl)
	local i = 1;
	if (next(tbl) ~= nil) then
		for itemID, itemInfo in pairs(tbl) do
			while i <= 8 do
				if tbl[itemID]["hasSellPrice"] then
					local itemCount = GetItemCount(tbl[itemID]["itemLink"], false); local sellPrice = itemCount * select(11, GetItemInfo(tbl[itemID]["itemLink"]));
					itemProfit = itemProfit + CalculateProfit(tbl[itemID]["itemLink"]);
					UseContainerItem(tbl[itemID]["bag"], tbl[itemID]["slot"]);
				else
					PickupContainerItem(tbl[itemID]["bag"], tbl[itemID]["slot"]);
					DeleteCursorItem();
					deletedItemCount = deletedItemCount + 1;
				end
				tbl[itemID] = nil;
				i = i + 1; break;
			end
		end
	else
		print(L["ADDON_NAME"] .. L["NO_ITEMS"]);
	end

	if deletedItemCount > 0 then
		print(L["ADDON_NAME"] .. L["DELETED_ITEM"] .. deletedItemCount .. L["DELETED_ITEM_TEXT"]);
		deletedItemCount = 0;
	end
	
	if next(tbl) ~= nil then
		SellItems(tbl);
	else
		if itemProfit > 0 then
			print(L["ADDON_NAME"] .. L["SOLD_ITEMS"] .. GetCoinTextureString(itemProfit, 12));
		end
		itemProfit = 0;
	end
end

local function ScanInventory(skipSellPhase)
	for i = 0, (NUM_BAG_FRAMES + 1) do -- The constant is equal to 4.
		for j = 1, GetContainerNumSlots(i) do
			local _, itemCount, _, quality, _, _, itemLink, _, _, itemID = GetContainerItemInfo(i, j);
			
			if skipSellPhase == false then
				if itemID then -- This accounts for empty slots and items without an ID.
					if itemCount then
						if (quality < 1) then -- This is a poor quality item.
							if DoesItemHaveSellPrice(itemLink) then
								sellIndices[itemID] = {bag = i, slot = j, hasSellPrice = true, itemLink = itemLink};
							else
								sellIndices[itemID] = {bag = i, slot = j, hasSellPrice = false};
							end
						else
							if (Contains(itemID)) then -- This is an item that the player added to the database.
								if itemHasNoSellPrice then
									sellIndices[itemID] = {bag = i, slot = j, hasSellPrice = false};
								else
									local itemString = string.match(select(3, strfind(itemLink, "|H(.+)|h")), "(.*)%[");
									sellIndices[itemID] = {bag = i, slot = j, hasSellPrice = true, itemLink = itemLink};
								end
							end
						end
					end
				end
			else
				if itemID then
					if quality < 1 then -- Poor quality items.
						PickupContainerItem(i, j);
						DeleteCursorItem();
						cleanedItems = cleanedItems + 1;
					elseif Contains(itemID) then -- An item added to the database by the player.
						PickupContainerItem(i, j);
						DeleteCursorItem();
						cleanedItems = cleanedItems + 1;
					end
				end
			end
		end
	end
	
	if cleanedItems > 0 then
		print(L["ADDON_NAME_HEADER"] .. ": " .. L["CLEAN_OUTPUT"]);
	end
	
	if deletedItemCount > 0 then
		print(L["ADDON_NAME"] .. L["DELETED_ITEM"] .. deletedItemCount .. L["DELETED_ITEM_TEXT"]);
		deletedItemCount = 0;
	end
	
	if skipSellPhase == false then
		SellItems(sellIndices);
	end
end

local function Report(func, ret, val)
	if func == "Add" then
		if ret == "+" then
			--print(L["ADDON_NAME"] .. L["ADDED_ITEM"] .. val .. ".");
		end
	elseif func == "Remove" then
		if ret == "+" then
			--print(L["ADDON_NAME"] .. L["REMOVED_ITEM"] .. val .. ".");
		end
	else
		if ret == "+" then
			print(L["ADDON_NAME"] .. val .. L["CANNOT_ADD_ITEM"]);
		end
	end
end

local function Remove(arg, tbl, index)
	table.remove(tbl, index);
	Report("Remove", "+", arg);
end

local function Add(arg, tbl)
	if tonumber(arg) ~= nil then -- We're dealing with some numbers.
		for i in string.gmatch(arg, "%S+") do
			i = tonumber(i);
			for index, id in ipairs(tbl) do
				if tbl[index] == i then
					addItem = false;
					Remove(i, tbl, index);
					--Report("Remove", "+", i);
					break;
				end
			end
			if tbl == CuratorClassicSellListPerCharacter then -- Check if the item is in the account list.
				for k, v in ipairs(CuratorClassicSellList) do
					if v == i then
						Report("", "+", i);
						return;
					end
				end
			else -- Check if the item exists in the character list.
				for k, v in ipairs(CuratorClassicSellListPerCharacter) do
					if v == i then
						table.remove(CuratorClassicSellListPerCharacter, k);
					end
				end
			end
			if addItem then
				tbl[#tbl + 1] = tonumber(i);
				--Report("Add", "+", i);
				return true;
			else
				addItem = true;
				return false;
			end
		end
	else -- We're dealing with some item links.
		local itemLinks = { strsplit("][", arg) };

		for k, v in ipairs(itemLinks) do
			local _, itemLink = GetItemInfo(itemLinks[k]);
			if itemLink then
				local itemID = GetItemInfoInstant(itemLink);
				for index, id in ipairs(tbl) do
					if tbl[index] == itemID then
						addItem = false;
						Remove(itemID, tbl, index);
					end
				end
				if tbl == CuratorClassicSellListPerCharacter then
					for k, v in ipairs(CuratorClassicSellList) do
						if v == itemID then
							Report("", "+", itemID);
							return;
						end
					end
				else -- Check if the item exists in the character list.
					for k, v in ipairs(CuratorClassicSellListPerCharacter) do
						if v == itemID then
							table.remove(CuratorClassicSellListPerCharacter, k);
						end
					end
				end
				if addItem then
					tbl[#tbl + 1] = tonumber(itemID);
					--Report("Add", "+", itemLink);
					return true;
				else
					addItem = true;
					return false;
				end
			end
		end
	end
end

local function ClearIterations()
	iter = 0;
	accountItemTotal = 0;
end

local function DisplayItemInfo(tooltip)
	if (curatorClassicSettings["disableDisplayInfo"] == false) then
		local _, itemLink = tooltip:GetItem();
		
		if (itemLink) then
			local itemID = (GetItemInfoInstant(itemLink));
			local _, _, _, _, _, _, _, maxStackCount = GetItemInfo(itemLink);
			
			if itemID then
				if curatorClassicItemInfo[itemID] then -- The item is in the account table.
					if maxStackCount ~= curatorClassicItemInfo[itemID]["maxStackCount"] then -- Did the max stack count possibly change?
						curatorClassicItemInfo[itemID]["maxStackCount"] = maxStackCount;
					end
					
					if GetItemCount(itemID, true) ~= curatorClassicItemInfo[itemID]["itemCount"][characterName] then -- Did the player receive more of said item?
						curatorClassicItemInfo[itemID]["itemCount"][characterName] = GetItemCount(itemID, true);
					end
				else -- The item is missing from the account table.
					curatorClassicItemInfo[itemID] = {maxStackCount = maxStackCount, itemCount = {[characterName] = GetItemCount(itemID, true)}}
				end
				
				local stop = 0;
				for _ in pairs(curatorClassicItemInfo[itemID]["itemCount"]) do
					stop = stop + 1;
				end
				
				for _, count in pairs(curatorClassicItemInfo[itemID]["itemCount"]) do
					if iter < stop then
						accountItemTotal = accountItemTotal + count;
						iter = iter + 1;
					end
				end
				
				tooltip:AddDoubleLine(L["ITEM_ID"] .. "\n" .. L["ITEM_STACK"] .. "\n" .. L["ITEM_COUNT"] .. "\n" .. L["SELL_PRICE"], 
				itemID .. "\n" .. curatorClassicItemInfo[itemID]["maxStackCount"] .. "\n" .. curatorClassicItemInfo[itemID]["itemCount"][characterName] .. " (" .. accountItemTotal .. ")" .. "\n" .. 
				GetCoinTextureString(select(11, GetItemInfo(itemID)) * GetItemCount(itemID, false), 12), 1, 1, 0, 1, 1, 1);
				tooltip:Show();
			end
		end
	end
end

local function Repair()
	local money = GetMoney();
	
	if money > (repairCost + 100) then -- The player has at least one silver more than the repair cost.
		RepairAllItems(); -- Use player money to fund the repairs.
	else
		print(L["ADDON_NAME"] .. L["LOW_FUNDS"] .. "(" .. GetCoinTextureString(repairCost, 12) .. ")");
	end
end

local function GetItemLinkFromTooltip(tooltip)
	local itemName, itemLink = tooltip:GetItem();
	
	if itemName and itemLink then
		tooltipLink = itemLink;
	end
end

-- The first tooltip after login returns 'nil'. Ask Blizzard; I have no idea...
function CuratorClassicHandleKeyPress(key)
	if (key == GetBindingKey("CURATORCLASSIC_CHARACTER_LIST")) then -- Character List
		GameTooltip:HookScript("OnTooltipSetItem", GetItemLinkFromTooltip);
		
		if tooltipLink then
			Add(tooltipLink, CuratorClassicSellListPerCharacter);
		end
	elseif (key == GetBindingKey("CURATORCLASSIC_ACCOUNT_LIST")) then -- Account List
		GameTooltip:HookScript("OnTooltipSetItem", GetItemLinkFromTooltip);
		
		if tooltipLink then
			Add(tooltipLink, CuratorClassicSellList);
		end
	elseif (key == GetBindingKey("CURATORCLASSIC_CHEAPEST_ITEM")) then -- Identify Cheapest Item
		curatorClassicNS.ScanInventory(false);
	elseif (key == GetBindingKey("CURATORCLASSIC_DISABLE_DISPLAY_INFO")) then -- Disable Display Item Info
		if (curatorClassicSettings["disableDisplayInfo"] == true) then
			curatorClassicSettings["disableDisplayInfo"] = false;
		else
			curatorClassicSettings["disableDisplayInfo"] = true;
		end
	end
end

-- Event Registrations
frame:RegisterEvent("MERCHANT_SHOW");
frame:RegisterEvent("MERCHANT_CLOSED");
frame:RegisterEvent("PLAYER_LOGIN");

SLASH_curatorclassic1 = "/curatorclassic";
SlashCmdList["curatorclassic"] = function(cmd, editbox)
	local _, _, cmd, args = string.find(cmd, "%s?(%w+)%s?(.*)");
	
	if not cmd or cmd == "" then
		print(L["ADDON_NAME_HEADER"] .. ": " .. L["BAD_COMMAND"]);
	elseif cmd == L["CLEAN"] then
		ScanInventory(true);
	end
end

frame:SetScript("OnEvent", function(self, event, ...)
	if event == "PLAYER_LOGIN" and isAddonLoaded then
		if curatorClassicSettings == nil then
			curatorClassicSettings = {};
			curatorClassicSettings["disableDisplayInfo"] = false;
		end
		
		if CuratorClassicSellListPerCharacter == nil then
			CuratorClassicSellListPerCharacter = {};
		end
		
		if CuratorClassicSellList == nil then
			CuratorClassicSellList = {};
		end
		
		if (curatorClassicItemInfo == nil) then
			curatorClassicItemInfo = {};
		end
		
		for i, j in ipairs(CuratorClassicSellList) do -- If an item is in both lists, then remove it from the individual character list.
			for k, v in ipairs(CuratorClassicSellListPerCharacter) do
				if v == j then
					table.remove(CuratorClassicSellListPerCharacter, k);
				end
			end
		end
		
		GameTooltip:HookScript("OnTooltipSetItem", DisplayItemInfo);
	end

	if event == "MERCHANT_SHOW" then
		repairCost = GetRepairAllCost();
		if repairCost > 0 then -- The player has items that need repaired.
			Repair();
		end
		ScanInventory(false);
	end
end);

local function DoesItemExist(tooltip)
	local frame, text;
	local _, itemLink = tooltip:GetItem();
	
	if not itemLink then return end;
	
	local itemID = GetItemInfoInstant(itemLink);
	
	if not itemID then return end;
	
	for i = 1, #CuratorClassicSellList do
		if CuratorClassicSellList[i] == itemID then
			tooltip:AddLine(L["ADDON_NAME_HEADER"].. ": " .. L["ACCOUNT_LIST"]);
			tooltip:Show();
			break;
		end
	end
	
	for j = 1, #CuratorClassicSellListPerCharacter do
		if CuratorClassicSellListPerCharacter[j] == itemID then
			tooltip:AddLine(L["ADDON_NAME_HEADER"] .. ": " .. L["CHAR_LIST"]);
			tooltip:Show();
			break;
		end
	end
end

GameTooltip:HookScript("OnTooltipSetItem", DoesItemExist);
GameTooltip:SetScript("OnHide", ClearIterations);
mouseFrame:SetScript("OnKeyDown", HandleKeyPress);
mouseFrame:SetPropagateKeyboardInput(true);