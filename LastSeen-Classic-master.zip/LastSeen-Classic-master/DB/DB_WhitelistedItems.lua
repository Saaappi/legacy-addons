local addon, addonTbl = ...;
local L = addonTbl.L;

local whitelistedItems = {
};

addonTbl.whitelistedItems = whitelistedItems;