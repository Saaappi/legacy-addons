-- Namespace Variables
local addon, addonTbl = ...;

-- Local Variables
local L = addonTbl.L;

local vendors = {
	[100995]		= "Auto-Hammer",
};

addonTbl.vendors = vendors;