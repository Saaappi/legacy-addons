local addonName, t = ...
local confirms = { -- An integer-indexed array of the events that should be registered to the addon's ScriptHandler.
};

t.confirms = confirms