--[[
	The purpose of the addon is to tell the player how much anima is in their inventory on demand.
]]--

--[[ TODO
]]--

--[[
	These variables are provided to the addon by Blizzard.
		addonName	: This is self explanatory, but it's the name of the addon.
		t			: This is an empty table. This is how the addon can communicate between files or local functions, sort of like traditional classes.
]]--
local addonName, t = ...;

-- Functions
t.Contains = function(tbl, value) -- Search the table for a specific value.
	for _, petData in ipairs(tbl) do
		if petData == value then -- A match on either the pet's ID or its name.
			return true;
		end
	end
	return false; -- No match, so add the pet to t.pets.
end

t.CagePets = function()
	for i = 1, #t.pets do
		local speciesID = C_PetJournal.GetPetInfoByPetID(t.pets[i]);
		local numCollected = C_PetJournal.GetNumCollectedInfo(speciesID);
		if numCollected == 1 then -- We re-run this check because we don't want to cage pets if it will cause all of them to be caged.
			table.remove(t.pets, i);
		else
			C_PetJournal.CagePetByID(t.pets[i]);
			table.remove(t.pets, i);
		end
		break
	end
	
	C_Timer.After(0, function()
		C_Timer.After(0.5, function() -- A small break between each cage is required, else Blizzard cuts us off.
			t.CagePets();
		end);
	end);
end

t.FindPets = function(name)
	local petSpeciesID, petGUID = C_PetJournal.FindPetIDByName(name);
	if (petGUID ~= nil) or (petGUID ~= "") then
		local speciesName, speciesIcon = C_PetJournal.GetPetInfoBySpeciesID(petSpeciesID);
		local popup = StaticPopupDialogs["CAGEPETS_RETURNBOX"];
		if not popup then
			popup = {
				button1 = "OK",
				timeout = timeout,
				showAlert = true,
				whileDead = true,
				hideOnEscape = true,
				enterClicksFirstButton = true,
				hasEditBox = true,
				OnAccept = function(self)
					if popup.callback then
						popup.callback(self.editBox:GetText());
					end
				end,
				preferredIndex = 3,  -- avoid some UI taint, see http://www.wowace.com/announcements/how-to-avoid-some-ui-taint/
			};
			StaticPopupDialogs["CAGEPETS_RETURNBOX"] = popup;
		end
		popup.OnShow = function (self, data)
			self.editBox:SetText(petGUID);
			self.editBox:SetJustifyH("CENTER");
			self.editBox:SetWidth(240);
		end;
		popup.text = ("|cffFFFF66" .. addonName .. "|r\n" .. "Copy |T" .. speciesIcon .. ":0|t " .. speciesName .. "'s GUID from the edit box below or use its species ID." .. "\n" .. "Species ID: |cff7193FF" .. petSpeciesID .. "|r");
		popup.callback = callback;
		StaticPopup_Hide ("CAGEPETS_RETURNBOX");
		StaticPopup_Show ("CAGEPETS_RETURNBOX");
	end
end