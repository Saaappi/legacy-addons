--[[
	The purpose of the addon is to tell the player how much anima is in their inventory on demand.
]]--

--[[ TODO
]]--

--[[
	These variables are provided to the addon by Blizzard.
		addonName	: This is self explanatory, but it's the name of the addon.
		t			: This is an empty table. This is how the addon can communicate between files or local functions, sort of like traditional classes.
]]--
local addonName, t = ...;

local e = CreateFrame("Frame");

-- Button Creation
local cagePetsDuplicatePetsButton;
local cagePetsFindPetsButton;

-- Event Registrations
e:RegisterEvent("ADDON_LOADED");

-- Button Functions
local function CagePetsDuplicatePetsButton_OnEnter()
	GameTooltip:SetOwner(cagePetsDuplicatePetsButton, "ANCHOR_RIGHT");
	GameTooltip:AddLine("|cffFFFF66" .. addonName .. "|r\n|cffFFFFFFFunction:|r Cage\n|cffFFFFFFDescription:|r Cages duplicate pets below level 25 that haven't been excluded.", 0.94, 0.59, 0.36, 1);
	GameTooltip:Show();
end

local function CagePetsDuplicatePetsButton_OnLeave()
	GameTooltip:Hide();
end

local function CagePetsDuplicatePetsButton_OnClick()
	local _, numOwned = C_PetJournal.GetNumPets();
	for i = 1, numOwned do
		local petID, speciesID, isOwned, _, petLevel, _, _, speciesName, _, _, _, _, _, _, _, isTradeable = C_PetJournal.GetPetInfoByIndex(i);
		if isTradeable and isOwned then -- The pet is tradeable, which means it should be cageable. Also, the player owns the pet.
			numCollected = C_PetJournal.GetNumCollectedInfo(speciesID);
			if numCollected > 1 then -- We don't want to cage a pet if we only have one collected of that pet.
				if petLevel < 25 then -- We don't want level 25s to be caged.
					-- If the pet is excluded, don't add it to the list to be caged.
					if t.Contains(t.excludedPets, petID) ~= true and t.Contains(t.excludedPets, tonumber(speciesID)) ~= true and t.Contains(t.excludedPets, speciesName) ~= true then
						table.insert(t.pets, petID);
					end
				end
			end
		end
	end
	t.CagePets();
end

local function CagePetsFindPetButton_OnEnter()
	GameTooltip:SetOwner(cagePetsDuplicatePetsButton, "ANCHOR_RIGHT");
	GameTooltip:AddLine("|cffFFFF66" .. addonName .. "|r\n|cffFFFFFFFunction:|r Find\n|cffFFFFFFDescription:|r Finds a pet by name and returns its pet ID and species ID.", 0.94, 0.59, 0.36, 1);
	GameTooltip:Show();
end

local function CagePetsFindPetButton_OnLeave()
	GameTooltip:Hide();
end

local function CagePetsFindPetButton_OnClick()
	local popup = StaticPopupDialogs["CAGEPETS_FINDBOX"];
	if not popup then
		popup = {
			text = "Enter the name of the pet you want to find.",
			button1 = "Find",
			timeout = timeout,
			showAlert = true,
			whileDead = true,
			hideOnEscape = true,
			enterClicksFirstButton = true,
			hasEditBox = true,
			OnAccept = function(self)
				t.FindPets(self.editBox:GetText());
			end,
			preferredIndex = 3,  -- avoid some UI taint, see http://www.wowace.com/announcements/how-to-avoid-some-ui-taint/
		};
		StaticPopupDialogs["CAGEPETS_FINDBOX"] = popup;
	end
	popup.OnShow = function (self, data)
		self.editBox:SetText("");
		self.editBox:SetJustifyH("CENTER");
		self.editBox:SetWidth(160);
	end;
	popup.callback = callback;
	StaticPopup_Hide ("CAGEPETS_FINDBOX");
	StaticPopup_Show ("CAGEPETS_FINDBOX");
end

e:SetScript("OnEvent", function(self, event, addon)
	if event == "ADDON_LOADED" and addon == "Blizzard_Collections" then
		-- Create the buttons. Set their size and position on the Pet Journal.
		cagePetsDuplicatePetsButton = CreateFrame("Button", "CagePetsCagePetsDuplicatePetsButton", PetJournal, "SecureFrameTemplate");
		cagePetsDuplicatePetsButton:SetWidth(34);
		cagePetsDuplicatePetsButton:SetHeight(34);
		cagePetsDuplicatePetsButton:SetNormalTexture("Interface\\AddOns\\CagePets\\ICONS\\cage_normal");
		cagePetsDuplicatePetsButton:SetHighlightTexture("Interface\\AddOns\\CagePets\\ICONS\\cage_highlight");
		cagePetsDuplicatePetsButton:SetPushedTexture("Interface\\AddOns\\CagePets\\ICONS\\cage_pushed");
		cagePetsDuplicatePetsButton:SetPoint("TOPRIGHT", PetJournal.SummonRandomFavoritePetButton, "TOPLEFT", -15, 0);
		
		cagePetsFindPetsButton = CreateFrame("Button", "CagePets-CagePetsDuplicatePetsButton", PetJournal, "SecureFrameTemplate");
		cagePetsFindPetsButton:SetWidth(34);
		cagePetsFindPetsButton:SetHeight(34);
		cagePetsFindPetsButton:SetNormalTexture("Interface\\AddOns\\CagePets\\ICONS\\find_normal");
		cagePetsFindPetsButton:SetHighlightTexture("Interface\\AddOns\\CagePets\\ICONS\\find_highlight");
		cagePetsFindPetsButton:SetPushedTexture("Interface\\AddOns\\CagePets\\ICONS\\find_pushed");
		cagePetsFindPetsButton:SetPoint("TOPRIGHT", cagePetsDuplicatePetsButton, "TOPLEFT", -1, 0);
		
		
		-- Hide the side text of the existing buttons.
		PetJournalHealPetButtonSpellName:Hide();
		PetJournalSummonRandomFavoritePetButtonSpellName:Hide();
		
		-- Move the existing buttons closer together.
		PetJournal.SummonRandomFavoritePetButton:SetPoint("TOPRIGHT", PetJournal.HealPetButton, "TOPLEFT", -4, 0);
		
		-- Button OnEnter
		cagePetsDuplicatePetsButton:SetScript("OnEnter", CagePetsDuplicatePetsButton_OnEnter);
		cagePetsFindPetsButton:SetScript("OnEnter", CagePetsFindPetButton_OnEnter);
		
		-- Button OnLeave
		cagePetsDuplicatePetsButton:SetScript("OnLeave", CagePetsDuplicatePetsButton_OnLeave);
		cagePetsFindPetsButton:SetScript("OnLeave", CagePetsFindPetButton_OnLeave);
		
		-- Button Click
		cagePetsDuplicatePetsButton:SetScript("OnClick", CagePetsDuplicatePetsButton_OnClick);
		cagePetsFindPetsButton:SetScript("OnClick", CagePetsFindPetButton_OnClick);
	end
end);