--[[
	These variables are provided to the addon by Blizzard.
		addonName	: This is self explanatory, but it's the name of the addon.
		t			: This is an empty table. This is how the addon can communicate between files or local functions, sort of like traditional classes.
]]--
local addonName, t = ...;

-- These pets won't be caged. You need the pet's GUID, species ID, or name.
local excludedPets = {};

local pets = {};

t.excludedPets = excludedPets;
t.pets = pets;