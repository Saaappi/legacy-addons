local JunkOrNot, ns = ...;
local isJunk, notJunk = "|cffFF0000Junk|r", "|cff00FF7FNot Junk|r";
local artifacts = {
  [158075] = notJunk, -- Heart of Azeroth
};

ns.artifacts = artifacts;
