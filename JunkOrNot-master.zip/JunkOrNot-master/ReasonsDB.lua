local JunkOrNot, ns = ...;
local reasonsDB = {
  [1], "This is a mount, pet, or toy.",
  [2], "This item can no longer be obtained.",
  [3], "",
};

ns.reasonsDB = reasonsDB;
